<div id="pyre_homepage_media-widget-product-feat-2" class="widget home-widget pyre_homepage_media-product-feat">
		<div class="footer-highlight-home pyre_homepage_media-widget-product-feat-2 light-fonts-pro">
			<div class="footer-highlight-home-border">
				<div class="width-container">
					<h2 class="footer-highlight-widget">¿NECESITA AYUDA?</h2>
					<div class="summary-text-pro">CONTÁCTENOS Y CON GUSTO LO ATENDEREMOS</div> 
						<a href="<?php echo $site_url;?>contacto.html" class="progression-button">Contáctenos<i class="ls-sc-button-icon-right fa fa-envelope-o"></i></a>
				<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>

<div id="widget-area">
    <div class="width-container">
        <div id="full-width-progression">						
            <div id="content-container-full-width">
                <div class="content-container-pro">
                    <div class="ls-sc-grid_5 alpha widget">
                        <h6 class="widget-title">Dirección</h6>
                        <p><strong>Farmaceútica Mundial de Venezuela C.A.</strong><br />
                        Av. 68 cruce con Calle 101 Urbanización Industrial Castillito<br />
                        C.C. Boulevar Local #7<br />
                        Valencia (Estado Carabobo)<br />Republica Bolivariana de Venezuela
                        </p>
                    </div>
                    <div class="ls-sc-grid_3 widget">
                        <h6 class="widget-title">Teléfonos</h6>
                        <p>241-8717406 / 241-8716420</p>
                        <h6 class="widget-title">Email</h6>
                        <p>farmuvenca@gmail.com</p>
                    </div>
                    <div class="ls-sc-grid_4 omega widget">
                        <h6 class="widget-title">Redes Sociales</h6>
                        <div class="social-ico">
                            <a href="http://facebook.com" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="http://twitter.com" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="http://plus.google.com" target="_blank"><i class="fa fa-google-plus"></i></a>
                            <a href="http://instagram.com" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="http://pinterest.com" target="_blank"><i class="fa fa-pinterest"></i></a>
						</div>
                    </div>
                    <div class="clear"></div>	
                </div><!-- close .content-container-pro -->
            </div>
            <div class="clearfix"></div>
        </div>
    </div><!-- close .width-container -->
    <div class="clearfix"></div>
</div>

<div id="widget-area">
	<footer>
		<div id="copyright">
			<div class="width-container"> © 2015 Farmaceútica Mundial de Venezuela C.A. - Todos los derechos reservados.</div>
		<div class="clearfix"></div>
		</div>
	</footer>
</body>
</html>